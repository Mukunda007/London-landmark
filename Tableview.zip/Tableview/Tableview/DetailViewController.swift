//
//  DetailViewController.swift
//  Tableview
//
//  Created by Mukunda Pote on 19/10/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit
import MapKit

class DetailViewController: UIViewController {
    
    var sentData1: String!
    var sentData2: String!
    var sentData3: String!
    
    @IBOutlet weak var detailImageView: UIImageView!
   
    @IBOutlet weak var detailTitle: UILabel!
    @IBOutlet weak var detailDescription: UILabel!
    
    @IBOutlet weak var detailTextView: UITextView!
    
    @IBOutlet weak var detailMapView: MKMapView!
    
    @IBOutlet weak var directionButton: UIButton!
    
    var latitude = 0.0
    var longitude = 0.0
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        directionButton.layer.cornerRadius = 5
        detailMapView.layer.cornerRadius = 5

        self.navigationItem.title = sentData1
        
        detailTitle.text = sentData1
        detailDescription.text = sentData2
        detailImageView.image = UIImage(named: sentData3)
        
        if detailTitle.text == "Big Ben"{
            detailTextView.text = "Big Ben is the nickname for the Great Bell of the striking clock at the north end of the Palace of Westminster in London;[1] the name is frequently extended to refer to both the clock and the clock tower.[2][3] The official name of the tower in which Big Ben is located was originally the Clock Tower; it was renamed Elizabeth Tower in 2012 to mark the Diamond Jubilee of Elizabeth II, Queen of the United Kingdom."
            
            latitude = 20.01
            longitude = 73.78
        }
        if detailTitle.text == "Buckingham Palace"{
            
            detailTextView.text = "Buckingham Palace is the London residence and administrative headquarters of the monarch of the United Kingdom.[a][3] Located in the City of Westminster, the palace is often at the centre of state occasions and royal hospitality. It has been a focal point for the British people at times of national rejoicing and mourning.Originally known as Buckingham House, the building at the core of today's palace was a large townhouse built for the Duke of Buckingham in 1703 on a site that had been in private ownership for at least 150 years. It was acquired by King George III in 1761 as a private residence for Queen Charlotte and became known as The Queen's House. During the 19th century it was enlarged, principally by architects John Nash and Edward Blore, who constructed three wings around a central courtyard. Buckingham Palace became the London residence of the British monarch on the accession of Queen Victoria in 1837."
            latitude = 51.500841
            longitude = -0.142988
        }
        if detailTitle.text == "London Eye"{
                   detailTextView.text = "The London Eye, or the Millennium Wheel, is a cantilevered observation wheel on the South Bank of the River Thames in London. It is Europe's tallest cantilevered observation wheel,[14] and is the most popular paid tourist attraction in the United Kingdom with over 3 million visitors annually,[15] and has made many appearances in popular culture."
            latitude = 51.50328
            longitude = -0.119687
               }
               
        if detailTitle.text == "St Pauls"{
                   detailTextView.text = "St Paul's Cathedral is an Anglican cathedral in London, United Kingdom, which, as the cathedral of the Bishop of London, serves as the mother church of the Diocese of London. It sits on Ludgate Hill at the highest point of the City of London and is a Grade I listed building. Its dedication to Paul the Apostle dates back to the original church on this site, founded in AD 604.[1] The present cathedral, dating from the late 17th century, was designed in the English Baroque style by Sir Christopher Wren. Its construction, completed in Wren's lifetime, was part of a major rebuilding programme in the City after the Great Fire of London.[2][page needed] The earlier Gothic cathedral (Old St Paul's Cathedral), largely destroyed in the Great Fire, was a central focus for medieval and early modern London, including Paul's walk and St Paul's Churchyard being the site of St Paul's Cross."
            latitude = 40.447367
            longitude = -79.949818
               }
               
        if detailTitle.text == "Tower Bridge"{
                   detailTextView.text = "Tower Bridge is a combined bascule and suspension bridge in London, built between 1886 and 1894. The bridge crosses the River Thames close to the Tower of London and has become a world-famous symbol of London. As a result, it is sometimes confused with London Bridge, about half a mile (0.8 km) upstream. Tower Bridge is one of five London bridges owned and maintained by the Bridge House Estates, a charitable trust overseen by the City of London Corporation. It is the only one of the trust's bridges not to connect the City of London directly to the Southwark bank, as its northern landfall is in Tower Hamlet"
            latitude = 51.505499
            longitude = -0.075358
               }
               
        if detailTitle.text == "Westminster Abbey"{
                   detailTextView.text = "Westminster Abbey, formally titled the Collegiate Church of Saint Peter at Westminster, is a large, mainly Gothic abbey church in the City of Westminster, London, England, just to the west of the Palace of Westminster. It is one of the United Kingdom's most notable religious buildings and the traditional place of coronation and burial site for English and, later, British monarchs. The building itself was a Benedictine monastic church until the monastery was dissolved in 1539. Between 1540 and 1556, the abbey had the status of a cathedral. Since 1560, the building is no longer an abbey or a cathedral, having instead the status of a Church of England Royal Peculiar—a church responsible directly to the sovereign."
            latitude =  51.499362
            longitude = -0.1274
               }
        
        
        
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: CLLocationCoordinate2DMake(latitude, longitude), span: span)
        
        detailMapView.setRegion(region, animated: true)
        
        let pinLocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude, longitude)
        let pinAnn = MKPointAnnotation()
        
        pinAnn.coordinate = pinLocation
        pinAnn.title = detailTitle.text
        pinAnn.subtitle = detailDescription.text
        
        self.detailMapView.addAnnotation(pinAnn)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func button(_ sender: Any) {
        
        UIApplication.shared.open(URL(string: "http://maps.apple.com/maps?daddr=\(latitude),\(longitude)")!, options: [:], completionHandler: nil)
        
    }
    
      
}

